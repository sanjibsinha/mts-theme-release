<?php
/**
 * The template for displaying all single application posts.
 *
 * @package My_Tech_Stack
 */

get_header();
?>

<main id="primary" class="site-main application-main">
    <div class="container" style="max-width: 800px; margin: 0 auto; padding: 2rem 20px;">

        <?php
        while ( have_posts() ) :
            the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                
                <header class="entry-header" style="margin-bottom: 2rem;">
                    <?php the_title( '<h1 class="entry-title" style="font-size: 2.5rem; color: #1a1a1a; margin-bottom: 1rem;">', '</h1>' ); ?>
                </header>

                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="app-featured-image" style="margin-bottom: 2rem;">
                        <?php the_post_thumbnail( 'full', array( 'style' => 'width: 100%; height: auto; max-width: 800px;' ) ); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content" style="line-height: 1.8; color: #444; font-size: 1.1rem;">
                    <?php the_content(); ?>
                </div>

                <!-- Custom Field Logic: Multiple Downloads & Custom Texts -->
                <?php 
                $download_url = get_post_meta( get_the_ID(), 'download_url', true );
                $button_text = get_post_meta( get_the_ID(), 'button_text', true ) ?: 'Download Application';
                
                $download_url_2 = get_post_meta( get_the_ID(), 'download_url_2', true );
                $button_text_2 = get_post_meta( get_the_ID(), 'button_text_2', true ) ?: 'Download Plugin';

                $app_version = get_post_meta( get_the_ID(), 'app_version', true );
                
                if ( ! empty( $download_url ) ) : 
                ?>
                    <div class="application-action-buttons" style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #eaeaea; display: flex; flex-wrap: wrap; align-items: center; gap: 15px;">
                        
                        <!-- Primary Button (e.g., Theme) -->
                        <a href="<?php echo esc_url( $download_url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-download" style="display: inline-block; background-color: #e91e63; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; transition: opacity 0.3s ease;">
                            <?php echo esc_html( $button_text ); ?>
                        </a>

                        <!-- Secondary Button (e.g., Plugin) -->
                        <?php if ( ! empty( $download_url_2 ) ) : ?>
                            <a href="<?php echo esc_url( $download_url_2 ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-download-secondary" style="display: inline-block; background-color: #1a1a1a; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; transition: opacity 0.3s ease;">
                                <?php echo esc_html( $button_text_2 ); ?>
                            </a>
                        <?php endif; ?>
                        
                        <!-- Version Badge -->
                        <?php if ( ! empty( $app_version ) ) : ?>
                            <span class="app-version-badge" style="background-color: #f4f4f4; color: #1a1a1a; padding: 6px 12px; border-radius: 4px; font-size: 0.9rem; font-weight: bold; border: 1px solid #ccc;">
                                Version: <?php echo esc_html( $app_version ); ?>
                            </span>
                        <?php endif; ?>

                    </div>
                <?php endif; ?>

            </article>

        <?php endwhile; ?>

    </div>
</main>

<?php get_footer(); ?>