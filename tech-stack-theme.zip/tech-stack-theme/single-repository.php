<?php
/**
 * The template for displaying all single repository posts.
 *
 * @package My_Tech_Stack
 */

get_header();
?>

<main id="primary" class="site-main repository-main">
    <div class="container" style="max-width: 800px; margin: 0 auto; padding: 2rem 20px;">

        <?php
        while ( have_posts() ) :
            the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                
                <header class="entry-header" style="margin-bottom: 2rem;">
                    <?php the_title( '<h1 class="entry-title" style="font-size: 2.5rem; color: #1a1a1a; margin-bottom: 1rem;">', '</h1>' ); ?>
                </header>

                <!-- Featured Image (SVG Fix) -->
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="repo-featured-image" style="margin-bottom: 2rem;">
                        <?php the_post_thumbnail( 'full', array( 'style' => 'width: 100%; height: auto; max-width: 800px;' ) ); ?>
                    </div>
                <?php endif; ?>

                <!-- Main Content (The Narrative) -->
                <div class="entry-content" style="line-height: 1.8; color: #444; font-size: 1.1rem;">
                    <?php 
                        the_content(); 
                    ?>
                </div>

                <!-- Custom Field Logic: GitHub URL -->
                <?php 
                $github_url = get_post_meta( get_the_ID(), 'github_url', true );
                if ( ! empty( $github_url ) ) : 
                ?>
                    <div class="repository-action-buttons" style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #eaeaea;">
                        <a href="<?php echo esc_url( $github_url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-github" style="display: inline-block; background-color: #1a1a1a; color: #f4f4f4; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; transition: background-color 0.3s ease;">
                            View Source on GitHub
                        </a>
                    </div>
                <?php endif; ?>

            </article>

        <?php
        endwhile; 
        ?>

    </div>
</main>

<?php
get_footer();