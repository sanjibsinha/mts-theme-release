<footer class="site-footer" style="padding: 3rem 20px; border-top: 1px solid #eaeaea; margin-top: 4rem; text-align: center;">
    
    <?php
    if ( has_nav_menu( 'footer_menu' ) ) {
        wp_nav_menu( array(
            'theme_location' => 'footer_menu',
            'container'      => 'nav',
            'container_class'=> 'footer-nav-container',
            'menu_class'     => 'footer-menu-list',
            'depth'          => 1,
            'fallback_cb'    => false,
        ) );
    }
    ?>

    <!-- Basic Inline CSS for the Footer Menu Grid -->
    <style>
        .footer-menu-list {
            list-style: none;
            padding: 0;
            margin: 0 0 1.5rem 0;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .footer-menu-list a {
            text-decoration: none;
            color: #444;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .footer-menu-list a:hover {
            color: #e91e63;
        }
    </style>

    <div class="site-info" style="color: #777; font-size: 0.9rem;">
        &copy; <?php echo date( 'Y' ); ?> My Tech Stack. Developed by Sanjib Sinha & Gemini AI.
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>